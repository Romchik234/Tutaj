function oblicz()
{
    let miasto = document.getElementById("miasto").value; 
    let kwota = 0; 
    let liczbaRat = document.getElementById("liczbaRat").value;
 
    let checkboxReact = document.getElementById("Reactjs");
    if(checkboxReact.checked)
        kwota += 5000; 

    let checkboxJavaScipt =  document.getElementById("JavaScript");
    if(checkboxJavaScipt.checked)
        kwota += 3000; 

    let rata = kwota / liczbaRat;
    document.getElementById("wynik").innerText = "Kurs odbedzie się w " + miasto + ". Koszt całkowity: " + kwota + " zl. Płacisz " + liczbaRat  + " rat po " + rata;
}