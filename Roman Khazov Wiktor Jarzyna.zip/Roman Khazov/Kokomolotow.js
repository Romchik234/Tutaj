function ChangeColor(number)
{
    /*document.querySelector('.stolik').style.background= "green";*/
    const element = document.querySelectorAll('.stolik');
    switch (number) {
        case 1:
            element[0].style.background = "green" ;
            break;
        case 2: 
            element[1].style.background = "green" ;
            break;


        case 3: 
            element[2].style.background = "green" ;
            break;

        case 4: 
            element[3].style.background = "green" ;
            break;

        case 5: 
            element[4].style.background = "green" ;
            break;

        case 6: 
            element[5].style.background = "green" ;
            break;

        case 7: 
            element[6].style.background = "green" ;
            break;

        case 8: 
            element[7].style.background = "green" ;
            break;

        case 9: 
        element[8].style.background = "green" ;
        break; 
    }
}

function ChangeColorBack(number)
{
    const element = document.querySelectorAll('.stolik');
    switch (number) {
        case 1:
            element[0].style.background = "lightskyblue" ;
            break;
        case 2: 
            element[1].style.background = "lightskyblue" ;
            break;


        case 3: 
            element[2].style.background = "lightskyblue" ;
            break;

        case 4: 
            element[3].style.background = "lightskyblue" ;
            break;

        case 5: 
            element[4].style.background = "lightskyblue" ;
            break;

        case 6: 
            element[5].style.background = "lightskyblue" ;
            break;

        case 7: 
            element[6].style.background = "lightskyblue" ;
            break;

        case 8: 
            element[7].style.background = "lightskyblue" ;
            break;

        case 9: 
        element[8].style.background = "lightskyblue" ;
        break; 
    }
}